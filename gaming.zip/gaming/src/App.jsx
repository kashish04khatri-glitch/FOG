import { useState, useEffect } from "react";
import { motion } from "framer-motion";

const THEMES = {
  neon: ["#39FF14", "#00FFEF", "#FF00E4"],
  ocean: ["#0077FF", "#00E5FF", "#00FFB7"],
  cyberpunk: ["#FF0077", "#FF00FF", "#FFD700"],
};

export default function App() {
  const [time, setTime] = useState(0);
  const [theme, setTheme] = useState("neon");
  const [lockedCells, setLockedCells] = useState(new Set());
  const [gridSize, setGridSize] = useState({ rows: 15, cols: 20 });

  // Wave time
  useEffect(() => {
    const interval = setInterval(() => {
      setTime((t) => t + 1);
    }, 120);
    return () => clearInterval(interval);
  }, []);

  // Auto Theme Cycle
  useEffect(() => {
    const interval = setInterval(() => {
      setTheme((prev) =>
        prev === "neon" ? "ocean" : prev === "ocean" ? "cyberpunk" : "neon"
      );
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  // Responsive grid size
  useEffect(() => {
    const updateGrid = () => {
      if (window.innerWidth < 640) {
        setGridSize({ rows: 10, cols: 10 });
      } else if (window.innerWidth < 1024) {
        setGridSize({ rows: 15, cols: 20 });
      } else {
        setGridSize({ rows: 20, cols: 30 });
      }
    };
    updateGrid();
    window.addEventListener("resize", updateGrid);
    return () => window.removeEventListener("resize", updateGrid);
  }, []);

  const handleClick = (row, col) => {
    const key = `${row}-${col}`;
    setLockedCells((prev) => {
      const next = new Set(prev);
      next.has(key) ? next.delete(key) : next.add(key);
      return next;
    });
  };

  const { rows, cols } = gridSize;

  return (
    <div className="relative min-h-screen flex items-center justify-center bg-gradient-to-br from-black via-gray-900 to-black overflow-hidden">
      {/* Scanner Line */}
      <motion.div
        className="absolute top-0 left-0 w-full h-1 bg-green-400 shadow-[0_0_20px_#39FF14]"
        animate={{ y: ["0%", "100%"] }}
        transition={{ repeat: Infinity, duration: 5, ease: "linear" }}
      />

      {/* Grid */}
      <div
        className="grid"
        style={{ gridTemplateColumns: `repeat(${cols}, minmax(12px, 24px))` }}
      >
        {Array.from({ length: rows }).map((_, row) =>
          Array.from({ length: cols }).map((_, col) => {
            const distance = Math.abs(
              Math.sin((time / 5 + row + col) * 0.3)
            );
            const colors = THEMES[theme];
            const color = colors[(row + col + time) % colors.length];
            const key = `${row}-${col}`;
            const isLocked = lockedCells.has(key);

            return (
              <motion.div
                key={key}
                onClick={() => handleClick(row, col)}
                whileHover={{ scale: 1.4 }}
                animate={{
                  scale: isLocked ? 1.3 : 1 + distance * 0.5,
                  backgroundColor: isLocked ? "#FFD700" : color,
                }}
                transition={{ duration: 0.3 }}
                className="w-6 h-6 m-[1px] rounded-sm shadow-md cursor-pointer"
              />
            );
          })
        )}
      </div>
    </div>
  );
}

