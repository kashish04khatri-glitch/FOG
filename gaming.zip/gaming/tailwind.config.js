/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./index.html",          // root HTML file
    "./src/**/*.{js,ts,jsx,tsx}", // src folder ke sare React files
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
